# Project_2
Instructions:
1. Interactive mode
- To enter interactive mode, simply start the program.
- additionally, you can add an internal command as an optional argument which will also enter interactive mode.
2. Internal Commands
- CD -h, -H, -l [n], -c, -s
- Exit